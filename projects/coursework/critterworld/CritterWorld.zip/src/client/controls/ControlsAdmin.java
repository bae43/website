package client.controls;

import client.App;

@SuppressWarnings("serial")
public class ControlsAdmin extends Controls {

	public ControlsAdmin(App frame) {
		super(frame);
		permTitle.setText(" Moderator ");
	}

}
